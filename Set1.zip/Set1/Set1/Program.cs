﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Set1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            string number = Console.ReadLine();
            int num = Int32.Parse(number);
            if (num <= 10)
            {
                Console.WriteLine("this number is too small.");
            }
            else if (num == 10 || num > 10)
            {
                Console.WriteLine("This number is big enough");
            }
        }
        }
    }
  
