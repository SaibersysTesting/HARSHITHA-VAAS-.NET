﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
//Set up an array/List of the following musical instruments:
//cello
//guitar
//violin
//double bass
//Loop round and remove the vowels for each word.
namespace Set4
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList music = new ArrayList();
            music.Add("cello");
            music.Add("guitar");
            music.Add("violin");
            music.Add("double bass");
            Console.WriteLine("before removing vowels ,The list is:");
            for (int i = 0; i < music.Count; i++)
            {
                Console.WriteLine(music[i]);

            }

            Console.WriteLine("After removing vowels:");

            for (int i = 0; i < music.Count; i++)
            {
                string value = music[i] as string;
                string s2 = System.Text.RegularExpressions.Regex.Replace(value, "[aeiouAEIOU]", "");
                Console.WriteLine(s2);

            }

        }
    }
}
