﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Messagebox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            string[] a = { "Be happy", "stay positive","Keep smiling","Love your job","be creative" };
            int no = r.Next(0, 4);
            string mymsg = a[no];
            MessageBox.Show(mymsg);
        }
    }
}
