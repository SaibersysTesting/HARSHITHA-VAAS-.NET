﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write a program to work out if a series of 5 digits are consecutive numbers.
//To make this easier, assumes the digits are a string:

//string numbers = "10-9-8-7-6";

//Make sure your code works for the following sequence, as well:

//string numbers = "1-2-3-4-5";

namespace Set5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter numbers seperated by '-':");
            String numberstring = Console.ReadLine();
            string[] numbers = numberstring.Split('-');

            int counter = 0;

            for (int i = 0; i < numbers.Length - 1; i++)
            {
                int first_num = int.Parse(numbers[i]);
                int second_num = int.Parse(numbers[i + 1]);

                if (first_num > second_num)
                {
                    if (first_num - second_num == 1)
                    {
                        counter++;
                    }
                }
                else
                {
                    if (second_num - first_num == 1)
                    {
                        counter++;
                    }
                }
            }
            if (counter == numbers.Length - 1)
            {
                Console.WriteLine("consecutive numbers");
            }
            else
            {
                Console.WriteLine(" not consecutive numbers");
            }




        }
    }
}
