﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication
{
    public partial class Index : System.Web.UI.Page
    {
        public void Page_Load(object sender, EventArgs e)
        {
           

        }

        public void Button1_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Today;
            DateTime bday = Convert.ToDateTime(datepicker.Text);
            TimeSpan tm = today - bday;
            int age = tm.Days / 365;
            String name = Convert.ToString(TextBox1.Text);
            Label4.Text = name+" is "+Convert.ToString(age)+" yrs old.";
        }
    }

            }

