﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Product
{
    public partial class Form1 : Form
    {

        BAL.BAL_Class obj = new BAL.BAL_Class();

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj.p_Pno = Convert.ToInt32(textBox1.Text);
            obj.p_Pname = textBox2.Text;
            obj.p_Prate = double.Parse(textBox3.Text);


            obj.Bal_Insert();
            MessageBox.Show("Product Inserted Sucessfully.....");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }
    }
}
