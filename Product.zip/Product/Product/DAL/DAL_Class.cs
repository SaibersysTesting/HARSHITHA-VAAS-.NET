﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;



namespace Product.DAL
{
    class DAL_Class
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        SqlDataAdapter da = null;
        Connection conobj = new Connection();

        string query;


        public void DAL_Insert(BAL.BAL_Class obj)
        {
            con=conobj.MyProjectConnection();
            con.Open();

            query = "insert_product";
            cmd = new SqlCommand(query, con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.Add("@prm_pno", obj.p_Pno);
            cmd.Parameters.Add("@prm_pname", obj.p_Pname); 
            cmd.Parameters.Add("@prm_prate", obj.p_Prate);
            cmd.ExecuteNonQuery();

            // close connection
            con.Close();


        }


    }
}
