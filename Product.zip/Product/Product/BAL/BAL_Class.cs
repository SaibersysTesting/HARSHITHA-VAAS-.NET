﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product.BAL
{
    class BAL_Class
    {
        public int p_Pno
        {
            get;
            set;
        }
        public string p_Pname
        {
            get;
            set;
        }
        public Double p_Prate
        {
            get;
            set;
        }
        DAL.DAL_Class obj = new DAL.DAL_Class();
        public void Bal_Insert()
        {
            obj.DAL_Insert(this);
        }



    }
}
