﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write a program that asks the user to enter an integer, then gets the input from the user.
//The program should repeatedly ask the user to enter an integer until the user enters an integer greater than 10; 
//then it should print "Integer greater than 10 detected!" and should end.

namespace Set3
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("enter an integer.");
                string number = Console.ReadLine();
                int num = Int32.Parse(number);
                if (num > 10)
                {
                    Console.WriteLine("Integer greater than 10 detected!");
                    break;
                }

                Console.WriteLine("the number is " + num);





            }

        }
    }
}
