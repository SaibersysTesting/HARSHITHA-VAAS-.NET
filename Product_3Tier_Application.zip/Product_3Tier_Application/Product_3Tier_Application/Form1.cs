﻿using Product_3Tier_Application.BAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Product_3Tier_Application
{
    public partial class Form1 : Form
    {
        BAL_product_Class obj = new BAL_product_Class();

        public void clearall()
        {
            textBox_pno.Clear();
            textBox_pname.Clear();
            textBox_prate.Clear();
            textBox_pno.Focus();

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // store textbox values into bal class variables
            obj.pno = int.Parse(textBox_pno.Text);
            obj.pname = textBox_pname.Text;
            obj.prate = double.Parse(textBox_prate.Text);

            // Call Bal Function
            obj.Bal_Insert_Product();

            MessageBox.Show(" Product Inserted Sucessfully....");

            clearall();



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // store textbox values into bal class variables
            obj.pno = int.Parse(textBox_pno.Text);
            obj.pname = textBox_pname.Text;
            obj.prate = double.Parse(textBox_prate.Text);

            // Call Bal Function
            obj.Bal_Update_Product();

            MessageBox.Show(" Product Update Sucessfully....");

            clearall();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // store textbox values into bal class variables
            obj.pno = int.Parse(textBox_pno.Text);
           

            // Call Bal Function
            obj.Bal_Delete_Product();

            MessageBox.Show(" Product Deleted Sucessfully....");

            clearall();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds=obj.Bal_Display_Product_Details();

            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Refresh();
        }
    }
}
