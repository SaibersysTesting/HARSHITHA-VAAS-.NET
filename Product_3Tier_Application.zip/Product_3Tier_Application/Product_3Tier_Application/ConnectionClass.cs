﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Product_3Tier_Application
{
    class ConnectionClass
    {
        public SqlConnection MyProjectConnection()
        {
            string strconn = ConfigurationManager.ConnectionStrings["ProductConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(strconn);
            return con;
        }
    }
}
