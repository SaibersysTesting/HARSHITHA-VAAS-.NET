﻿using Product_3Tier_Application.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_3Tier_Application.BAL
{
    class BAL_product_Class
    {
        public int pno
        {
            get;
            set;
        }

        public string pname
        {
            get;
            set;
        }

        public double prate
        {
            get;
            set;
        }

        DAL_product_Class obj = new DAL_product_Class();

        public void Bal_Insert_Product()
        {
            // call DAL Insert function 
            obj.Dal_Insert_Product(this);
        }

        public void Bal_Update_Product()
        {
            // call DAL Insert function 
            obj.Dal_Update_Product(this);
        }

        public void Bal_Delete_Product()
        {
            // call DAL Delete function 
            obj.Dal_Delete_Product(this);
        }

        public DataSet Bal_Display_Product_Details()
        {

            return obj.Dal_Display_Product_Details();
        }
    }
}
