﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Product_3Tier_Application.BAL;
using System.Data;

namespace Product_3Tier_Application.DAL
{
    class DAL_product_Class
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataSet ds = new DataSet();

        string query = "";
        ConnectionClass conobj = new ConnectionClass();

        public void Dal_Insert_Product(BAL_product_Class obj)
        {
            con = conobj.MyProjectConnection();
            con.Open();

            query = "insert into product_tbl values(@prm_pno,@prm_pname,@prm_prate)";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.Add("@prm_pno", obj.pno);
            cmd.Parameters.Add("@prm_pname", obj.pname);
            cmd.Parameters.Add("@prm_prate", obj.prate);
            cmd.ExecuteNonQuery();

            con.Close();

        }

        public void Dal_Update_Product(BAL_product_Class obj)
        {
            con = conobj.MyProjectConnection();
            con.Open();

            query = "update product_tbl set Pname=@prm_pname,Prate=@prm_prate where Pno=@prm_pno";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.Add("@prm_pno", obj.pno);
            cmd.Parameters.Add("@prm_pname", obj.pname);
            cmd.Parameters.Add("@prm_prate", obj.prate);
            cmd.ExecuteNonQuery();

            con.Close();
        }


        public void Dal_Delete_Product(BAL_product_Class obj)
        {

            con = conobj.MyProjectConnection();
            con.Open();

            query = "delete from product_tbl where Pno=@prm_pno";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.Add("@prm_pno", obj.pno);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        public DataSet Dal_Display_Product_Details()
        {
            con = conobj.MyProjectConnection();
            con.Open();

            query = "select * from product_tbl";
            cmd = new SqlCommand(query, con);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "product");

            return ds;
                       
            
        }
    }
}
