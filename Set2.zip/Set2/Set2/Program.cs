﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Set2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number");
            string number = Console.ReadLine();
            int num = Int32.Parse(number);

            switch (num)
            {
                case 1:
                    Console.WriteLine("Only one ? ");
                    break;

                case 100:
                    Console.WriteLine("100....thats alot!!");
                    break;


                default:
                    Console.WriteLine("Input not recognized.");
                    break;

            }
            }
        }
}
